package com.cognizant.ormlearn.testapp;

import com.cognizant.ormlearn.service.CountryJpaImpl;
import com.cognizant.ormlearn.service.CountryHibernateImpl;
import com.cognizant.ormlearn.service.CountryService;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class ApplicationTest {
    public static void main(String[] args) {
        System.out.println("Spring Data JPA:");
        try (AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext("com.cognizant.ormlearn")) {
            CountryService countryService = context.getBean(CountryService.class);
            System.out.println(countryService.getAllCountries());
        }

        System.out.println("\nJPA:");
        CountryJpaImpl jpaImpl = new CountryJpaImpl();
        System.out.println(jpaImpl.findCountry("IN"));

        System.out.println("\nHibernate:");
        CountryHibernateImpl hibernateImpl = new CountryHibernateImpl();
        System.out.println(hibernateImpl.findCountry("IN"));
    }
}
