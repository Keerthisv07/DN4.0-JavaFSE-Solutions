package com.cognizant.ormlearn.service;

import com.cognizant.ormlearn.model.Country;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class CountryJpaImpl {

    public Country findCountry(String code) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("country-unit");
        EntityManager em = emf.createEntityManager();

        Country country = em.find(Country.class, code);

        em.close();
        emf.close();

        return country;
    }
}
