package com.cognizant.ormlearn;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.cognizant.ormlearn.model.Country;
import com.cognizant.ormlearn.service.CountryService;
import com.cognizant.ormlearn.exception.CountryNotFoundException;

@SpringBootApplication
public class OrmLearnApplication {

    private static final Logger LOGGER = LoggerFactory.getLogger(OrmLearnApplication.class);

    private static CountryService countryService;

    public static void main(String[] args) {
        ApplicationContext context = SpringApplication.run(OrmLearnApplication.class, args);
        LOGGER.info("Inside main");

        countryService = context.getBean(CountryService.class);

        try {
            testGetAllCountries();
            testFindCountryByCode();
            testAddCountry();
            testUpdateCountry();
            testFindCountriesByPartialName();
            testDeleteCountry();
        } catch (CountryNotFoundException e) {
            LOGGER.error("Exception in main flow: {}", e.getMessage());
        }
    }

    private static void testGetAllCountries() {
        LOGGER.info("Start");
        List<Country> countries = countryService.getAllCountries();
        LOGGER.debug("Countries = {}", countries);
        LOGGER.info("End");
    }

    private static void testFindCountryByCode() throws CountryNotFoundException {
        LOGGER.info("Start");
        Country country = countryService.findCountryByCode("IN");
        LOGGER.debug("Country = {}", country);
        LOGGER.info("End");
    }

    private static void testAddCountry() throws CountryNotFoundException {
        LOGGER.info("Start");
        Country country = new Country();
        country.setCode("ZZ");
        country.setName("Zootopia");
        countryService.addCountry(country);

        LOGGER.debug("Added Country: {}", countryService.findCountryByCode("ZZ"));
        LOGGER.info("End");
    }

    private static void testUpdateCountry() throws CountryNotFoundException {
        LOGGER.info("Start");
        countryService.updateCountry("ZZ", "Zootopian Republic");
        LOGGER.debug("Updated Country: {}", countryService.findCountryByCode("ZZ"));
        LOGGER.info("End");
    }

    private static void testDeleteCountry() throws CountryNotFoundException {
        LOGGER.info("Start");
        countryService.deleteCountry("ZZ");

        try {
            Country country = countryService.findCountryByCode("ZZ");
            LOGGER.debug("After delete, country = {}", country);
        } catch (CountryNotFoundException e) {
            LOGGER.debug("After delete, country not found as expected: {}", e.getMessage());
        }
        LOGGER.info("End");
    }

    private static void testFindCountriesByPartialName() {
        LOGGER.info("Start");
        List<Country> countries = countryService.findCountriesByPartialName("land");
        LOGGER.debug("Countries with 'land' in name = {}", countries);
        LOGGER.info("End");
    }
}
