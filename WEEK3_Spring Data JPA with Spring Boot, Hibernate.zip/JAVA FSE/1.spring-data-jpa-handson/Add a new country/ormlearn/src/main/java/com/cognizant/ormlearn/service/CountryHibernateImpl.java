package com.cognizant.ormlearn.service;

import com.cognizant.ormlearn.model.Country;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class CountryHibernateImpl {

    public Country findCountry(String code) {
        Configuration config = new Configuration().configure("hibernate.cfg.xml");
        config.addAnnotatedClass(Country.class);

        SessionFactory sessionFactory = config.buildSessionFactory();
        Session session = sessionFactory.openSession();

        Country country = session.get(Country.class, code);

        session.close();
        sessionFactory.close();

        return country;
    }
}
