package com.mycompany;

public interface ExternalApi {
    String getData();
}
